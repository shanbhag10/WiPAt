<?php
try {

    $dbh = new PDO('mysql:host=localhost;dbname=attendance',"bvjniot","m&qgG*~[qWpT");
    
    
} 
  catch(Exception $e)
    {
        echo "There was an error connecting to the database";
    }

?>
